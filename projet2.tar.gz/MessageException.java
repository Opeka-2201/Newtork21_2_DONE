public class MessageException extends Exception{
    public MessageException(String s){
        super(s);
    }
}
